from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='portstart-home'),
    path('about/', views.about, name='portstart-about'),
    path('contact/', views.contact, name='portstart-contact'),
]